Weekend Project: Employee Management App (Web base).

How to run:
- execute App.py and don't close it.
- Take the path and run it in the browser.


How it work:
- Landing Page based on HTML.
- Page style based on CSS.
- Page interactive based on Javascript.
- Page function based on App.py.

How it made:
- Create a local database with python.
- Create a landing page.
- Make a form in landing page.
- Insert form answer to database with python.
- Show the database in landing page with python.
- Edit/delete database row with python.

How can it growth:
- Add detail profile for each user.
- Make a good landing page.
- Add sick/leave qty

Detail:
- Two specific folder for flask: static and templates
- For features location (css, imgs, js), must include to static folder.
- For html file included in templates folder.